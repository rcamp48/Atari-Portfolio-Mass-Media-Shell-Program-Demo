/*
include-file fuer SFT.C, enthaelt fehlermeldungen und string-konstanten

*** deusche version ***

R. Henze,  15.11.90

last edit: 11.06.92
*/

unsigned char fo_errmess[] = "outputfile open error";
unsigned char fi_errmess[] = "inputfile open error";
unsigned char connection[] = "message from server: active!";

unsigned char m_filename[] = "\nfilename> ";
unsigned char m_file[]     = "\nfile ";
unsigned char m_closed[]   = " closed\n";
unsigned char m_stat[]     = " ,status: ";
unsigned char m_escp[]     = "<esc> pressed";
unsigned char nl[]         = "\n";
unsigned char m_block[]    = " block ";
unsigned char m_nack[]     = "\n nack!\n";
unsigned char m_transerr[] = "\ntransmission error";
unsigned char m_sending[]  = "\nsending file ";
unsigned char m_esce[]     = "(<esc> exits)";
unsigned char m_transm[]   = "\nfile transmitted";
unsigned char m_bse[]      = "\nblock sequence error";
unsigned char m_recov[]    = "\nrecovered!";
unsigned char m_chserr[]   = "\nchecksum error!";
unsigned char m_irrecov[]  = "\nirrecoverable!";
unsigned char m_rec[]      = "\nreceive file> ";
unsigned char m_startsend[]= "\nstart sender now ";
unsigned char m_sucrec[]   = "\nfile successfully received";
unsigned char m_receivng[] = "\nreceiving file ";
unsigned char m_send[]     = "\nsend file> ";
unsigned char m_backuprdy[]= "\nbackup completed";
unsigned char m_help0[]    = "\nSFT [baud] [com0,1] [delay]  (V3.4, RH)";
unsigned char m_help1[]    = "\nF1  receive     CNTRL F1 master receive";
unsigned char m_help2[]    = "\nF2  send        CNTRL F2 master send";
unsigned char m_help3[]    = "\nF3  send hexfil CNTRL F4 m. backup";
unsigned char m_help4[]    = "\nF5  toggle hex  F6       toggle logging";
unsigned char m_help5[]    = "\nF7  help        F8       exit";
unsigned char m_help6[]    = "\nF10 test line   F9       show logbuffer\n";
#ifndef ptf
unsigned char m_help7[]    = "\n                CNTRL F5 local editing";
#endif
unsigned char m_badbaud[]  = "\nbad baud rate";
unsigned char m_logging[]  = "logging on!\n";
unsigned char m_sendcom[]  = "send_com";
unsigned char m_ringbfful[]= " buffer full!\n";
unsigned char m_exit[]     = "\nf8/esc pressed.";

/*---------------------- end of file sftgmes.i -------------------------*/
