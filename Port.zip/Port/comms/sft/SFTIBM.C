/*
sft.c : ibm-pc specific routines

R. Henze   05.10.90
last edit: 21.07.93

*/

#define exit_com()        /*dummy*/
  
/* ------------------------------------------------------------------------ */

extern int  receive_com(int *adr);    /* get char form ser-port-buffer */
extern int  send_com(int chr);        /* send char to ser-port */
extern void exit_com();               /* close ser-port */

extern void cout(unsigned char c);    /* put char to console */
extern void put(unsigned char *ptr);  /* put string to console */
extern void hex(int i);               /* put hexnumber to console*/

extern int  port_stat;
extern int  tmdp_cnt;                 /*input (rs232c) buffer counter*/

#define     tmdp_len 0x500            /*input (rs232c) buffer length*/
#define     tmdp_lim (tmdp_len-100)   /**** definition in tmio.asm***/

/* ------------------------------------------------------------------------ */

extern void tmio_setup(int portpar);  /* initialize serial port */

#define noparity   0x00
#define oddparity  0x08
#define evenparity 0x18
#define dbits8     0x03
#define dbits7     0x02
#define sbits1     0x00
#define sbits2     0x04

void init_com(baud, port)
int baud;
unsigned int port;
{
unsigned int code;

code = 0x00f0 & (baud<<5);
code = code | noparity;
code = code | dbits8;
code = code | sbits1;

code = code | (0xff00 & (port<<8));

tmio_setup(code);

cbuf_ful = 0;
}

/* ------------------------------------------------------------------------ */

unsigned char conin()
 
{
int c;
int i;

c = bioskey(0);

i = c>>8;
/* function keys, incl. cntrl-function keys:*/
if ((i>0x3a && i<0x45) || (i>0x5c && i<0x68))
  {
  c = (c>>8) | 0x0080;
  }
else
  {
  c = c & 0x00ff;

/*return (c);*/
  }
return ((unsigned char)c);
}

/* ------------------------------- */

/*#define conout putch*/
#define conout cout

/* ------------------------------- */


int out_open(line)
unsigned char *line;
{
int i;
i = open(line,O_BINARY | O_WRONLY | O_CREAT);
if (i == -1)
  {
  quit(fo_errmess);
  }
return(i);
}

/* ------------------------------- */

int in_open(line)
unsigned char *line;
{
int i;
i = open(line,O_BINARY | O_RDONLY);
if (i == -1)
  {
  quit(fi_errmess);
  }
return(i);
}

/* ------------------------------------------------------------------------ */
/* --- file date and time ------------------------------------------------- */
/* ------------------------------------------------------------------------ */

struct ftime ftimep;      /* structure for file date and time */

void getftimdat()
{
ftimep.ft_tsec = get_com_chk(&dummy);
ftimep.ft_min = get_com_chk(&dummy);
ftimep.ft_hour = get_com_chk(&dummy);
ftimep.ft_day = get_com_chk(&dummy);
ftimep.ft_month = get_com_chk(&dummy);
ftimep.ft_year = get_com_chk(&dummy);
}

/* ------------------------------------------------------------------------ */

void putftimdat()
{
put_com(ftimep.ft_tsec);
put_com(ftimep.ft_min);
put_com(ftimep.ft_hour);
put_com(ftimep.ft_day);
put_com(ftimep.ft_month);
put_com(ftimep.ft_year);
}

/* ------------------------------------------------------------------------ */

void setfiletime(fh)
int fh;
{
setftime(fh,&ftimep);
}

/* ------------------------------------------------------------------------ */

void getfiletime(fh)
int fh;
{
getftime(fh,&ftimep);
}

/* ------------------------------------------------------------------------ */

/* end of file sftibm.i */

