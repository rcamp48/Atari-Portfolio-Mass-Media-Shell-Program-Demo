/*
Conversion of "C" source programs from "indent"-version to "bracket"-version
indent-version: brackets, which are necessary to mark program blocks
                are expressed by brackets, like in OCCAM and PROMAL, advantage
                of this method: programs become shorter and better readable
bracket-vers.:  normal method of C-syntax to mark program blocks: brackets

06.03.91:       extended to support ansii's double-slash-comment

Rolf Henze
Dorfstrasse 19
D-3300 Braunschweig
W.-Germany
phone: 0049-531-509839

sep 1990
last edit: 20.03.91
*/

/*---------------------------------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h>

#define true  1
#define false 0

#define linelen   256
unsigned char line[linelen];
unsigned char scratch[linelen];
int indent;
int i;
int errflg;
int stmflg;         /*true after 'comment-on', false after 'comment-off*/
int linecount;

/*---------------------------------------------------------------------------*/

/* test if line is statement or comment*/

int statement(str)
unsigned char *str;

  {
  int i;
  int flag;

  if (strlen(str)>0)                 /* if str is not empty*/
    {
    i=0;
    while (str[i]==0x20)             /* skip leading blanks */
      {
      i++;
      }
    if (str[i]!=0)
      {
      if (stmflg)
        {
        if (*(str+i) != '/')
          {
          flag = true;               /* statement */
          }
        else
          {
          if(*(str+i+1) == '*')
            {
            flag = false;            /* kommentar */
            }
          }
        }
      else
        {
        flag = false;
  
        }
      while (*(str+i) != 0)
        {
        if (*(str+i)=='/' && *(str+i+1)=='*')
          {
          stmflg = false;
          }
        else
          {
          if (*(str+i)=='*' && *(str+i+1)=='/')
            {
            stmflg = true;
            }
          }
        i++;

        }
      }
    else
      {
      flag = false;                  /* str enthaelt nur blanks */
  
      }
    }
  else
    {
    flag = false;                    /* str leer */

    }
  return flag;

/*---------------------------------------------------------------------------*/


  }
int indent_level(str)
unsigned char *str;

  {
  int i;
  /* calculates indent-level of*/
  /* PROMAL program line*/

  i=0;
  while (str[i]==0x20)
    {
    i++;
    }
  if (str[i]!=0)
    {
    if (i%2 != 0)
      {
      errflg = true;
      }
    return  i>>1;
    }
  else
    {
    return 0;

/*---------------------------------------------------------------------------*/

    }
  }
int indentation(level)
int level;

  {
  int i;
  int k;
  int l;

  l=indent_level(line);                  /* determine indent-level of input line*/
  if ((l-level) > 1)
    {
    errflg = true;

    }
  if (l!=level)                         /* insert bracket, if indent-level*/
    {
    if (l>level)                        /* has changed*/
      {
      i=0;
      if (l>0)                          /* insert blanks for indentation*/
        {
        while (i<2*l)
          {
          scratch[i] = 0x20;
          i++;
          }
        }
      scratch[i] = 0x7b;
      i++;
      scratch[i] = 0;
      puts(scratch);                   /* open bracket, and new line*/
      }
    else
      {
      k = level-1;
      while (k>=l)
        {
        i=0;
        if (k>-1)
          {
          while (i < 2*(k+1))
            {
            scratch[i] = 0x20;
            i++;
            }
          }
        scratch[i] = 0x7d;
        i++;
        scratch[i] = 0;
        puts(scratch);                 /* close bracket*/
        k--;
  
        }
      }
    }
  return l;

/*---------------------------------------------------------------------------*/

  }
void ext_cmt(str)       /* extend ansii's double-slash-comment */
unsigned char *str;

  {
  int i;
  int len;

  len = strlen(str);
  for (i=0; i<len; i++)
    {
    if (*(str+i)=='/' && *(str+i+1)=='/')
      {
      *(str+i+1) = '*';
      strcpy(str+len,"*/");
      break;

/*---------------------------------------------------------------------------*/

      }
    }
  }
void main()

  {
  errflg = false;
  stmflg = true;
  linecount = 0;
  indent = 0;
  
  while (gets(line)!=NULL)              /* read until EOF is detected*/
    {
    linecount++;
    ext_cmt(line);                      /* extend ansii's double-slash-comment*/
    if (statement(line))                /* if line is not empty or commnt*/
      {
      indent = indentation(indent);     /* determine id-level, set bracket*/
      }
    puts(line);
    if (errflg != false)                /* stop, if indentation error! */
      {
      fprintf(stderr,"\nindentation error line %d",linecount);
      exit(1);

      }
    }
  while (indent > 0)                  /* close open brackets, before leaving */
    {
    for (i=0; i<(indent<<1); i++)
      {
      scratch[i] = 0x20;
      }
    scratch[i] = 0x7d;
    i++;
    scratch[i] = 0;
    puts(scratch);
    indent--;

    }
  exit(0);
  
/*--------------------- end of file in_br.i ---------------------------------*/

  }
