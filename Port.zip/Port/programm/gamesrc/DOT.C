#include <dos.h>

int color=0;

void dot(int x, int y)
{
  union REGS inr,outr;

  inr.h.ah = 12;             /* write pixel */
  inr.h.al = color;
  inr.x.bx = 0;
  inr.x.dx = y;
  inr.x.cx = x;
  int86(16,&inr,&outr); /* call video intr */
}

