extern int color;
extern line();

void gboxr(x1, y1, x2, y2)
int x1, y1, x2, y2;
{
  color=0;
  line(x1, y1, x2, y1);
  line(x1, y1, x1, y2);
  line(x2, y1, x2, y2);
  line(x2, y2, x1, y2);
  color=1;
}
