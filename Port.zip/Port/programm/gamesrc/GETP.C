#include <dos.h>

int getp(int x, int y)
{
  union REGS inr,outr;

  inr.h.ah = 13;             /* read pixel */
  inr.x.bx = 0;
  inr.x.dx = y;
  inr.x.cx = x;
  int86(16,&inr,&outr); /* call video intr */
  return(outr.h.al);
}


