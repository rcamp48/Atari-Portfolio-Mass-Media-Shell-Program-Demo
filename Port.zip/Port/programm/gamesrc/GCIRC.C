extern dot();

double a_r = 0.666666;           /* Normal aspect ratio for circles. */

void gcirc(x1, y1, rad)
unsigned x1, y1;
long rad;
{
    unsigned i, j, k, r, x;

    r = rad*.75;
    rad *= rad;
    for(k = 0; k <= r; k++) {
        x = (sqrt((double)(rad - k*k)));
        i = a_r * x;
        dot(x1+k, y1+i);
        dot(x1-k, y1+i);
        dot(x1+k, y1-i);
        dot(x1-k, y1-i);
  
        j = a_r * k;
        dot(x1+x, y1+j);
        dot(x1-x, y1+j);
        dot(x1+x, y1-j);
        dot(x1-x, y1-j);
    }
}
