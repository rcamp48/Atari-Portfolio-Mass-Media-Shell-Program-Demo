extern dot();

/* Draws a line on the screen from (x1, y1) to (x2, y2) */
void line(int x1, int y1, int x2, int y2)
{


  register int xdelta;  /* The change in x coordinates */
  register int ydelta;  /* The change in y coordinates */
  register int xstep;   /* The change to make in the x coordinate in each step */
  register int ystep;   /* The change to make in the y coordinate in each step */
  register int change;  /* The amount that the x or y coordinate has changed */

  asm cli;

  xdelta = x2 - x1;               /* Calculate the change in x coordinates */
  ydelta = y2 - y1;               /* Calculate the change in y coordinates */
  if (xdelta < 0)
  {                                               /* The line will be drawn from right to left */
    xdelta = -xdelta;
    xstep = -1;
  }
  else                                    /* The line will be drawn from left to right */
    xstep = 1;
  if (ydelta < 0)
  {                                               /* The line will be drawn from bottom to top */
    ydelta = -ydelta;
    ystep = -1;
  }
  else                                    /* The line will be drawn from top to bottom */
    ystep = 1;
  if (xdelta > ydelta)    /* x changes quicker than y */
  {
    change = xdelta >> 1;  /* change set to twice the value of xdelta */
    while (x1 != x2)           /* Draw until the terminating dot is reached */
    {
      dot(x1, y1);                       /* Draw a dot on the screen */
      x1 += xstep;                            /* Update x coordinate */
      change += ydelta;                       /* Update change */
      if (change > xdelta)
      {
        y1 += ystep;       /* Update the y coordinate */
        change -= xdelta;  /* Reset change */
      }
    }
  }
  else                                       /* y changes quicker than x */
  {
    change = ydelta >> 1;  /* change set to twice the value of ydelta */
    while (y1 != y2)           /* Draw until the terminating dot is reached */
    {
      dot(x1, y1);                       /* Draw a dot on the screen */
      y1 += ystep;                            /* Update y coordinate */
      change += xdelta;                       /* Update change */
      if (change > ydelta)
                   /* If change is large enough to update the x coordinate */
      {
        x1 += xstep;            /* Update the x coordinate */
        change -= ydelta;       /* Reset change */
      }
    }
  }

  asm sti;

} /* line */

