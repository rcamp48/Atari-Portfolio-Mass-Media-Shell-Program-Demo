/*
        PROGRAM : MISS.C
        AUTHOR  : Jay Vaughan
        DATE    : February 15, 1992
        PURPOSE : Classic version of Missile Command for the ATARI Portfolio.
        NOTES   : Uses the GRLIB library to perform graphics functions.
        VERSION : 1.0 (JAY) - February 15, 1992 - rudimentary version 
                              programmed, incomplete.
*/


/* Header files */

#include <dos.h> 
#include <stdlib.h>

#include "grlib.h"
#include "miss.h"


#define RSHIFT 1
#define LSHIFT 2

#define NUMLSPTS 10     /* Number of points in the landscape */
#define NUMCITIES 3     /* Number of cities on the screen */
#define NUMMISL   5     /* Number of missiles on the screen at once */

/* Game variables */
int numshots=3;         /* # of shots the user can fire at one time */
int i;                  /* Used globally as an index variable */
int x1, y1, x2, y2;     /* Generic position variables */
int lives=3;            /* Number of lives left */
int mislcnt=0;          /* The current missile being drawn */
int chspeed=5;          /* How fast the cross hair moves */

struct l_s_point l_s[NUMLSPTS] = {
  {17,54}, {31,53},  {42,55},  {58,51},  {71,53},
  {89,56}, {101,52}, {120,57}, {131,51}, {155,53}
};

struct cityrec city[NUMCITIES] = {
  {30,53,CITYSAFE}, {71,53,CITYSAFE}, {120,56,CITYSAFE}
};

struct mislrec misl[NUMMISL] = {
  {15,10,MISLDEAD,SLOW,RIGHT}, 
  {55,10,MISLDEAD,SLOW,STRAIGHT}, 
  {45,10,MISLDEAD,MEDIUM,LEFT},
  {35,10,MISLDEAD,FAST,RIGHT},
  {30,10,MISLDEAD,SLOW,STRAIGHT}
};

struct c_h_rec c_h = {80,27};
struct c_h_rec oc_h;

void drawcities()
{
  for (i=0;i<NUMCITIES;i++)
    {
      line(city[i].x,   city[i].y,   city[i].x,   city[i].y-5); 
      line(city[i].x,   city[i].y-5, city[i].x+3, city[i].y-5); 
      line(city[i].x+3, city[i].y-5, city[i].x+3, city[i].y); 
      line(city[i].x,   city[i].y,   city[i].x,   city[i].y-3); 
      line(city[i].x,   city[i].y-3, city[i].x-2, city[i].y-3); 
      line(city[i].x-2, city[i].y-3, city[i].x-2, city[i].y); 
      dot(city[i].x+2, city[i].y-3);
      dot(city[i].x+1, city[i].y-1);
    }
}

void drawlandscape()
{
  x1=5;
  y1=58;

  for (i=0;i<NUMLSPTS;i++)
    {
      line(x1, y1, l_s[i].x, l_s[i].y);
      x1=l_s[i].x;
      y1=l_s[i].y;
    }
}

/* Initializes the playing field */
void initplayfield()
{
  videomode(GRAPHICS);
  color=1;
  gbox(0,0,239,63);
  gbox(5,5,155,58);
  line(5,29,7,29);     dot(5,27); dot(5,31);
  line(155,29,153,29); dot(155,27); dot(155,31);
  drawlandscape();
  drawcities();
}


void initmisl(int mislnum)
{
  misl[mislnum].x=52+random(56);
  misl[mislnum].y=10;
  switch(random(4))
    {
      case 0 : misl[mislnum].speed = FAST; break;
      case 1 : misl[mislnum].speed = SLOW; break;
      case 3 : misl[mislnum].speed = MEDIUM; break;
    }

  switch(random(4))
    {
      case 0 : misl[mislnum].dir = LEFT; break;
      case 1 : misl[mislnum].dir = STRAIGHT; break;
      case 3 : misl[mislnum].dir = RIGHT; break;
    }
  misl[mislnum].status=MISLSAFE;
}

void missile()
{
  color=0;
  dot(misl[mislcnt].x-misl[mislcnt].dir, 
      misl[mislcnt].y-misl[mislcnt].speed);
  dot(misl[mislcnt].x-(2*misl[mislcnt].dir),
      misl[mislcnt].y-(2*misl[mislcnt].speed));

  if ((misl[mislcnt].y>48)||
      (misl[mislcnt].status==MISLDEAD))
    initmisl(mislcnt);
  else
    {
      color=1;
      dot(misl[mislcnt].x, misl[mislcnt].y);
      dot(misl[mislcnt].x-misl[mislcnt].dir, 
          misl[mislcnt].y-misl[mislcnt].speed);

      misl[mislcnt].y+=misl[mislcnt].speed;
      misl[mislcnt].x+=misl[mislcnt].dir;
    }
  mislcnt=mislcnt<NUMMISL-1?mislcnt+1:0;
}

void idelay(long time)
{
  int n;
  for (n=0;n<=time;n++);
}

void fire()
{
  int fpos;
  fpos=c_h.x<75?7:153;

  color=1;
  line(fpos,29,c_h.x,c_h.y);
  color=0;
  line(fpos,29,c_h.x,c_h.y);
}


long keystate()
{
  union REGS inr, outr;

  inr.h.ah=02;
  int86(0x16, &inr, &outr);
  if (kbhit())
    getch();
  return(outr.x.ax);
}

void keyboard()
{
  char c;
  if (kbhit())
    {
      c=getch();
      switch (c)
        {
          case 'a' : ;
          case 'A' : c_h.x-=chspeed; break;  /* Left */

          case ';' : ;
          case ':' : c_h.x+=chspeed; break;  /* Left */

          case 'j' : ;
          case 'J' : c_h.y-=chspeed; break;  /* Up */

          case 'v' : ;
          case 'V' : c_h.y+=chspeed; break;  /* Down */

          case 32  : fire(); break; /* Fire */
          case 9   : chspeed=chspeed<5?chspeed+1:1; /* Change crosshair speed */
                     break;  
          case 27  : lives=-1;  /* Escape - means time to leave */
        }

    }

/*
    if (keystate()&LSHIFT) 
      c_h.x-=chspeed; /* Left 
    if (keystate()&RSHIFT)
      c_h.x+=chspeed; /* Right 
*/

  c_h.x=c_h.x<150?c_h.x:150;
  c_h.x=c_h.x>10?c_h.x:10;
  c_h.y=c_h.y<47?c_h.y:47;
  c_h.y=c_h.y>10?c_h.y:10;
}


void crosshair()
{
  if ((oc_h.x != c_h.x) ||
      (oc_h.y != c_h.y))
    {
      color=0;
      dot(oc_h.x-1, oc_h.y);
      dot(oc_h.x+1, oc_h.y);
      dot(oc_h.x, oc_h.y+1);
      dot(oc_h.x, oc_h.y-1);
      oc_h.x=c_h.x; oc_h.y=c_h.y;
    }

  color=1;
  dot(c_h.x-1, c_h.y);
  dot(c_h.x+1, c_h.y);
  dot(c_h.x, c_h.y+1);
  dot(c_h.x, c_h.y-1);
}


void main()
{
  initplayfield();

  while(lives>0)
    {
      missile();
      keyboard();
      crosshair();
    }

  getch();
  videomode(TEXT);
}

