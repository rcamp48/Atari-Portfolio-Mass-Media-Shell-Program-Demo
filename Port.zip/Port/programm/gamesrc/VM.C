#include <dos.h>

videomode(int mode)
{
  union REGS inr,outr;
  inr.h.ah=0;
  inr.h.al=mode;
  int86(16,&inr,&outr);
}

