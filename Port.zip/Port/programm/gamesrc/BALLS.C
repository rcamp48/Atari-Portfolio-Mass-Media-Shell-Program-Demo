/*      

  PROGRAM     : BALLS.C
  AUTHOR      : Jay Vaughan
  DATE        : 4 November 1991
  DESCRIPTION : Simple graphics game for the Atari Portfolio, using
                the GRLIB functions I developed for my Portfolio.
  NOTE        : See README.DOC for more information.
        
                      Copyright (C) 1991, 1992 Jay Vaughan

*/

#include <stdio.h> 
#include <conio.h>
#include <stdlib.h>
#include <time.h>

#include "grlib.h"
#include "keyb.h"
#include "gchar.h"

#define FIELDWIDTH 239
#define FIELDDEPTH 63

#define SCOREX 60 
#define SCOREY 28

#define MAXLOOPS 20
#define MAXBALLS 15

#define ON 1
#define OFF 0

#define DOWN 1

#define BOTTOM 63
#define TOP    0
#define LEFT   0  
#define RIGHT  239

int score, oscore=0;     /* Current score, last score */
int cb=0;                /* Current ball */
int numb=0;              /* Number of balls currently on the screen */
int loops=0;             /* Number of loops */
int savecol;
int catch_y=60;          /* Catchers Y position */
int catch_x=50;          /* Catchers X position */
int oldcatch_x=20;       /* Catchers old X position */
int NUMBALLS=11;


struct balldef {
  int xpos, ypos;  /* The balls location on the field */
  int oypos;       /* The balls old y_pos */
  int oxpos;       /* The balls old x_pos */
  int xdir;         /* The direction of the ball */ 
  int ydir;         /* The direction of the ball */ 
  int velocity;    /* Velocity of the ball */
  int currv;       /* Speed counter */
  int on;          /* Boolean, 0=off 1=on */
};

struct balldef ball[MAXBALLS];

idelay(long time)
{
  int n;
  for (n=0;n<=time;n++);
}

initb(i)
int i;
{
  ball[i].on=0;
  ball[i].xpos=0;
  ball[i].ypos=0;
  ball[i].velocity=ball[i].currv=1+random(3);
}

initbs()
{
  int i;
  for (i=0;i<MAXBALLS;i++)
    initb(i);
}


setball(bn)
int bn;
{
  if (ball[bn].on==0)
    {
      ball[bn].on=1;
      ball[bn].xpos=1+(random((FIELDWIDTH-3)/2)*2);
      ball[bn].ypos=1+(random((FIELDDEPTH-3)/2)*2);
      ball[bn].oxpos=ball[bn].xpos;
      ball[bn].oypos=ball[bn].ypos;
      ball[bn].xdir=randdir();
      ball[bn].ydir=randdir();
    }
}

randdir()
{
  return((random(2)?-1:1)*(random(5)+1));
}


initgr()   /* Initialize graphics screen */
{
  /* Go into graphics */
  videomode(CGAMODE);
  color=ON;
  line(LEFT,TOP, RIGHT,TOP);
  line(RIGHT,TOP, RIGHT,BOTTOM);
  line(RIGHT,BOTTOM, LEFT,BOTTOM);
  line(LEFT,BOTTOM, LEFT,TOP);
  gfill(LEFT,TOP,RIGHT,BOTTOM);
}

init()  /* Initialize graphics, program variables etc. */
{  
  randomize();
  initbs();
  initgr();
  score=0;
}

deinit()
{
  videomode(TEXTMODE);
}


plotballoff(bn)
int bn;
{
  color=OFF;
  dot(ball[bn].oxpos-1, ball[bn].oypos);
  dot(ball[bn].oxpos+1, ball[bn].oypos);
  dot(ball[bn].oxpos, ball[bn].oypos-1);
  dot(ball[bn].oxpos, ball[bn].oypos+1);

  dot(ball[bn].xpos-1, ball[bn].ypos);
  dot(ball[bn].xpos+1, ball[bn].ypos);
  dot(ball[bn].xpos, ball[bn].ypos-1);
  dot(ball[bn].xpos, ball[bn].ypos+1);
  color=ON;
}

plotball(bn)
int bn;
{  
  if (ball[bn].on)
    {
      if (ball[bn].currv<=0 )
        {
          color=OFF;
          dot(ball[bn].oxpos-1, ball[bn].oypos);
          dot(ball[bn].oxpos+1, ball[bn].oypos);
          dot(ball[bn].oxpos, ball[bn].oypos-1);
          dot(ball[bn].oxpos, ball[bn].oypos+1);

          color=ON;
          dot(ball[bn].xpos-1, ball[bn].ypos);
          dot(ball[bn].xpos+1, ball[bn].ypos);
          dot(ball[bn].xpos, ball[bn].ypos-1);
          dot(ball[bn].xpos, ball[bn].ypos+1);

          ball[bn].oypos=ball[bn].ypos;
          ball[bn].oxpos=ball[bn].xpos;
          ball[bn].ypos+=(ball[bn].ydir*ball[bn].velocity);
          ball[bn].xpos+=(ball[bn].xdir*ball[bn].velocity);
          ball[bn].currv=ball[bn].velocity;
        } 
      else
        ball[bn].currv--;
    }
}

plotballs()
{
  for(cb=0;cb<NUMBALLS;cb++)
    {
      plotball(cb);

      if (ball[cb].ypos>=BOTTOM-2)
        {
          ball[cb].ydir*=-1;
          ball[cb].ypos=BOTTOM-2;
        }
      if (ball[cb].ypos<=TOP+2)
        {
          ball[cb].ydir*=-1;
          ball[cb].ypos=TOP+2;
        }
      if (ball[cb].xpos>=RIGHT-2) 
        {
          ball[cb].xdir*=-1;
          ball[cb].xpos=RIGHT-2;
        }
      if (ball[cb].xpos<=LEFT+2)
        {
          ball[cb].xdir*=-1;
          ball[cb].xpos=LEFT+2;
        }

/*        {
          plotballoff(cb);
          initb(cb);
        }
*/
    }
}


play()
{
  while(NUMBALLS!=0)
    {
      if(keystate()&RSHIFT)
        {
          NUMBALLS=(NUMBALLS<MAXBALLS)?NUMBALLS+1:MAXBALLS;
          setball(NUMBALLS);
        }
      if(keystate()&LSHIFT)
        {
          NUMBALLS--;
          initb(numb);
        }

      plotballs();

/*      if (loops==MAXLOOPS)*/
        setball(++numb);

      if (numb>=NUMBALLS)
        numb=0;

      if (loops>MAXLOOPS)
        loops=0;
      else
        loops++;
    }
}

main()
{
  init();
  color=ON;
  play();
  deinit();
}

