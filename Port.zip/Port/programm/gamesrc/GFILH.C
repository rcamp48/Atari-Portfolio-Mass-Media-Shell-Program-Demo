extern line();

void gfilh(x1, y1, x2, y2)
int x1, y1, x2, y2;
{
    int tmp;

    if(y1 > y2)
        tmp = y2, y2 = y1, y1 = tmp;
    while(y1 <= y2) {
        line(x1, y1, x2, y1);
        y1 += 3;
    }
    if(y1 != y2)
        line(x1, y2, x2, y2);
}

