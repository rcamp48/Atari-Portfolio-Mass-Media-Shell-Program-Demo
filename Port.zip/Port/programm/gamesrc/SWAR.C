/*      

  PROGRAM     : SWAR.C
  AUTHOR      : Jay Vaughan
  DATE        : 4 November 1991
  DESCRIPTION : Simple graphics game for the Atari Portfolio, using
                the GRLIB functions I developed for my Portfolio.
  NOTE        : See README.DOC for more information.
        
                      Copyright (C) 1991, 1992 Jay Vaughan

*/

#include <dos.h> 
#include <stdio.h> 
#include <conio.h>
#include <stdlib.h>
#include <time.h>

#define ARROWAIT 250

#define CGAMODE 6
#define ON 1
#define OFF 0

#define RSHIFT 1
#define LSHIFT 2
#define FIRE   8
#define QUIT   1028

#define BG 0
#define YOU 1

#define NUMBALLS 8
#define DOWN    1
#define UP     -1
#define RESTING 0
#define STOPPED 0xff

#define LOOPTIME 5

struct balldef {
  int xpos, ypos;
  int oypos;
  int bdir;
  int velocity;
};

struct balldef ball[NUMBALLS];

int color=1, currpos, oldpos;
int done=0, instog, cnt=0;
int oldbgpos, bgpos, bgdir;
int whofired;
int szone=10;
int homein=0;
int cballn;
int indanger=0;
int score, bgscore=0;
int arrowup=0;
int arrowcnt=0;
int arrowx=0;
int lives;
int round=1;

videomode(int mode)
{
  union REGS inr,outr;
  inr.h.ah=0;
  inr.h.al=mode;
  int86(16,&inr,&outr);
}

videodot(int x, int y)
{
  union REGS inr,outr;

  inr.h.ah = 12;             /* write pixel */
  inr.h.al = color;
  inr.x.cx = x;
  inr.x.dx = y;
  int86(16,&inr,&outr); /* call video intr */
}

setballpos()
{
  ball[0].xpos=10;
  ball[0].ypos=30;
  ball[0].oypos=20;
  ball[0].bdir=RESTING;
  ball[0].velocity=1;
  ball[1].xpos=20;
  ball[1].ypos=30;
  ball[1].oypos=20;
  ball[1].bdir=RESTING;
  ball[1].velocity=1;
  ball[2].xpos=30;
  ball[2].ypos=30;
  ball[2].oypos=20;
  ball[2].bdir=RESTING;
  ball[2].velocity=1;
  ball[3].xpos=40;
  ball[3].ypos=30;
  ball[3].oypos=20;
  ball[3].bdir=RESTING;
  ball[3].velocity=1;
  ball[4].xpos=50;
  ball[4].ypos=30;
  ball[4].oypos=20;
  ball[4].bdir=RESTING;
  ball[4].velocity=1;
  ball[5].xpos=60;
  ball[5].ypos=30;
  ball[5].oypos=20;
  ball[5].bdir=RESTING;
  ball[5].velocity=1;
  ball[6].xpos=70;
  ball[6].ypos=30;
  ball[6].oypos=20;
  ball[6].bdir=RESTING;
  ball[6].velocity=1;
  ball[7].xpos=80;
  ball[7].ypos=30;
  ball[7].oypos=20;
  ball[7].bdir=RESTING;
  ball[7].velocity=1;
}


/* Draws a line on the screen from (x1, y1) to (x2, y2) */
line(int x1, int y1, int x2, int y2)
{
  register int xdelta;  /* The change in x coordinates */
  register int ydelta;  /* The change in y coordinates */
  register int xstep;   /* The change to make in the x coordinate in each step */
  register int ystep;   /* The change to make in the y coordinate in each step */
  register int change;  /* The amount that the x or y coordinate has changed */

  xdelta = x2 - x1;               /* Calculate the change in x coordinates */
  ydelta = y2 - y1;               /* Calculate the change in y coordinates */
  if (xdelta < 0)
  {                                               /* The line will be drawn from right to left */
    xdelta = -xdelta;
    xstep = -1;
  }
  else                                    /* The line will be drawn from left to right */
    xstep = 1;
  if (ydelta < 0)
  {                                               /* The line will be drawn from bottom to top */
    ydelta = -ydelta;
    ystep = -1;
  }
  else                                    /* The line will be drawn from top to bottom */
    ystep = 1;
  if (xdelta > ydelta)    /* x changes quicker than y */
  {
    change = xdelta >> 1;  /* change set to twice the value of xdelta */
    while (x1 != x2)           /* Draw until the terminating dot is reached */
    {
      videodot(x1, y1);                       /* Draw a dot on the screen */
      x1 += xstep;                            /* Update x coordinate */
      change += ydelta;                       /* Update change */
      if (change > xdelta)
      {
        y1 += ystep;       /* Update the y coordinate */
        change -= xdelta;  /* Reset change */
      }
    }
  }
  else                                       /* y changes quicker than x */
  {
    change = ydelta >> 1;  /* change set to twice the value of ydelta */
    while (y1 != y2)           /* Draw until the terminating dot is reached */
    {
      videodot(x1, y1);                       /* Draw a dot on the screen */
      y1 += ystep;                            /* Update y coordinate */
      change += xdelta;                       /* Update change */
      if (change > ydelta)
                   /* If change is large enough to update the x coordinate */
      {
        x1 += xstep;            /* Update the x coordinate */
        change -= ydelta;       /* Reset change */
      }
    }
  }
} /* line */

plotzapper(int zapper, int *xpos, int state)
{
  int ybase, yb1, yb2, yb3;

  if (*xpos<=4)
    *xpos=4;
  else
   if (*xpos>=95)
     *xpos=95;

  if (zapper==1)
    { yb1=0; yb2=1; yb3=2; ybase=57; }
  else
    { yb1=0; yb2=-1; yb3=-2; ybase=4; }

  color=state;
  videodot(*xpos+1, ybase+yb1);
  videodot(*xpos,   ybase+yb2);
  videodot(*xpos+1, ybase+yb2);
  videodot(*xpos+2, ybase+yb2);
  videodot(*xpos-1, ybase+yb3);
  videodot(*xpos,   ybase+yb3);
  videodot(*xpos+2, ybase+yb3);
  videodot(*xpos+3, ybase+yb3);
}

plotzapper2(int *xpos, int state)
{
  if (*xpos<=4)
    *xpos=4;
  else
   if (*xpos>=140)
     *xpos=140;

  color=state;
  videodot(*xpos+1, 5);
  videodot(*xpos,   4);
  videodot(*xpos+1, 4);
  videodot(*xpos+2, 4);
  videodot(*xpos-1, 3);
  videodot(*xpos,   3);
  videodot(*xpos+2, 3);
  videodot(*xpos+3, 3);
}

int shiftstate()
{
  union REGS inr, outr;
  inr.h.ah=02;
  int86(0x16, &inr, &outr);
  return(outr.h.al);
}

long keystate()
{
  union REGS inr, outr;

  inr.h.ah=02;
  int86(0x16, &inr, &outr);
  if (kbhit())
    getch();
  return(outr.x.ax);
}


idelay(long time)
{
  register int n;
  for (n=0;n<time;n++);
}

bounceballs(int dir)
{
  int j;
  arrowcnt=ARROWAIT;
  for (j=0;j<NUMBALLS;j++)
    {
      if (ball[j].bdir!=STOPPED) 
        ball[j].bdir=dir;
      else
      if (srand(2))
        ball[j].bdir=dir;
      ball[j].velocity=1;
    }
}

shoot()
{
  register int i, ballhit=0;
  register int ll;
  ll=2;
  if ((currpos>arrowx-2) &&
      (currpos<arrowx+2) &&
      (arrowup==1))
    {
      ll=33;
      bounceballs(UP);
    }
  else
  for (i=0;i<NUMBALLS;i++)
   {
     if ((currpos>ball[i].xpos-3)&&
         (currpos<ball[i].xpos+3))
       {
         if (ball[i].bdir==UP)
           if (ball[i].velocity<3)
             ball[i].velocity++;
           else
             ball[i].velocity=1;
         if ((ball[i].bdir==DOWN)||(ball[i].bdir==RESTING))
           {
             ball[i].bdir=UP;
             ball[i].velocity=1;
           }
         ll=ball[i].ypos;
         ballhit=1;
       }
   }

  plotzapper(1,&currpos, ON);
  color=ON;
  line(currpos+1, 55, currpos+1, ll);
  color=OFF;
  line(currpos+1, 55, currpos+1, ll);
  whofired=YOU;
  done=((ballhit==0)&&
        ((bgpos==currpos+1)||          
        (bgpos==currpos)||
        (bgpos==currpos+2)||
        (bgpos==currpos-1)||
        (bgpos==currpos+3)));
  if (done) 
    { 
      setballpos();
      round++;
    }
}

inspressed()
{
 register int i, ispressed;
 i=keystate()&FIRE;
  if (i!=instog)
    {
      ispressed=1;
      instog=i;
    }
  else
    ispressed=0;
 return(ispressed);
}                       

bgf()
{
  register int i, ballhit=0;
  register int ll;
  ll=56;
  if ((bgpos>arrowx-2) &&
      (bgpos<arrowx+2) &&
      (arrowup==1))
    {
      ll=33;
      bounceballs(DOWN);
    }
  else
  for (i=0;i<NUMBALLS;i++)
   {
     if ((bgpos>ball[i].xpos-3)&&
         (bgpos<ball[i].xpos+3))
       {
         if (ball[i].bdir==DOWN)
           if (ball[i].velocity<3)
             ball[i].velocity++;
           else
             ball[i].velocity=1;
         if ((ball[i].bdir==UP)||(ball[i].bdir==RESTING))
           {
             ball[i].bdir=DOWN;
             ball[i].velocity=1;
           }
         if (srand(11)<5)
           ball[i].velocity=3;
         ll=ball[i].ypos;
         ballhit=1;
       }
   }

  plotzapper(2,&bgpos, ON);
  color=ON;
  line(bgpos+1, 5, bgpos+1, ll);
  color=OFF;
  line(bgpos+1, 5, bgpos+1, ll);
  whofired=BG;

  
  if ((ballhit==0)&&
      ((bgpos==currpos+1)||          
      (bgpos==currpos)||
      (bgpos==currpos+2)||
      (bgpos==currpos-1)||
      (bgpos==currpos+3)))
    {
      lives--;
      color=ON;
      videodot(currpos+5, 58-5); 
      videodot(currpos-5, 58-5); 
      videodot(currpos+2, 58-3); 
      videodot(currpos-2, 58-3); 
      idelay(30000);
      done=1;
    }
}


plotball(int bn)
{
  color=OFF;
  videodot(ball[bn].xpos-1, ball[bn].oypos);
  videodot(ball[bn].xpos+1, ball[bn].oypos);
  videodot(ball[bn].xpos, ball[bn].oypos-1);
  videodot(ball[bn].xpos, ball[bn].oypos+1);
  color=ON;
  videodot(ball[bn].xpos-1, ball[bn].ypos);
  videodot(ball[bn].xpos+1, ball[bn].ypos);
  videodot(ball[bn].xpos, ball[bn].ypos-1);
  videodot(ball[bn].xpos, ball[bn].ypos+1);

  if (ball[bn].bdir!=STOPPED)
    {
      ball[bn].oypos=ball[bn].ypos;
      ball[bn].ypos+=(ball[bn].bdir*ball[bn].velocity);
      if (ball[bn].ypos<8) 
        {
          ball[bn].bdir=STOPPED;
          score++;
          ball[bn].ypos=7;
        }
      if (ball[bn].ypos>54)
        {
          ball[bn].bdir=STOPPED;
          bgscore++;
          ball[bn].ypos=55;
        }
    }
}

placearrow()
{
  videodot(arrowx,   30);
  videodot(arrowx-1, 31);
  videodot(arrowx,   31);
  videodot(arrowx+1, 31);
  videodot(arrowx,   32);
  videodot(arrowx,   33);
}

putarrowup(int arwcol)
{
  if (arwcol==ON)
    arrowx=srand(2)?3:95;
  color=arwcol;
  placearrow();
}


main(argc, argv)
int argc;
char *argv[];
{
  char *c;
  register int i;

  i=argc;  /* I hate warning messages ... */
  c=argv[1];
  
  switch (*c)
  {
    case 'h' : case 'H' : szone=15; homein=1; break;
    case 'm' : case 'M' : szone=10; break;
    case 'e' : case 'E' : szone=5; break;
    case '?' : 
    {        
       printf("Space War Usage:\n");
       printf("SWAR [h,m,e]\n");
       printf("     [H]ard [M]edium [E]asy\n");
       printf("Shift keys move left and right.  Alt key\n");
       printf("fires. The rest is very simple ...\n");
       printf("(c) ChimeTime Software\n");
       exit(1);
    }
  }

  instog=keystate()&FIRE;

  lives=3;

  setballpos();

  while (lives>0)
  {
    videomode(3);
    printf("Round : %d - Lives : %d\n", round, lives);
    printf("Score - Me : %d   You : %d\n", bgscore, score);
    idelay(30000);
    color=ON;
    videomode(CGAMODE);
    line(0, 0, 100, 0);
    line(100, 0, 100, 63);
    line(0, 63, 100, 63);
    line(0, 0, 0, 63);

    for (i=0;i<NUMBALLS;i++)
      plotball(i);

    done=0;
    bgpos=oldbgpos=10;
    oldpos=currpos=130;
    bgdir=srand(2)?-1:1; 
    cballn=arrowcnt=0;

    while(done==0)
    {
      if (arrowup!=1)
        if (srand(1001)==995)
          {
            putarrowup(ON);
            arrowup=1;
          }

      if ((arrowcnt==ARROWAIT)&&(arrowup==1))
        {
          plotzapper(1,&currpos, OFF);
          plotzapper(2,&bgpos, OFF);
          putarrowup(OFF);
          plotzapper(1,&currpos, ON);
          plotzapper(2,&bgpos, ON);
          arrowup=arrowcnt=0;
        }
      else 
        {
          if ((arrowcnt<ARROWAIT) && (arrowup==1)) 
            { 
              color=ON; 
              placearrow(); 
            }
          arrowcnt=(arrowcnt<ARROWAIT+1)?arrowcnt+1:0;
        }

      plotball(cballn);    /* Plot a ball */
      cballn=(cballn==NUMBALLS-1)?0:cballn+1;

      plotzapper(1,&currpos, ON);   /* Plot the players zapper */
      if (oldpos!=currpos)
        {
          plotzapper(1,&oldpos, OFF);
          oldpos=currpos;
        }

      plotzapper(2,&bgpos, ON);   /* Plot the computers zapper */
      if (bgpos!=oldbgpos)
        {
          plotzapper(2,&oldbgpos, OFF);
          oldbgpos=bgpos;
        }

      if (keystate()&RSHIFT)  /* Check the players keystrokes */
        currpos+=2;
      if (keystate()&LSHIFT)
        currpos-=2;
      if (inspressed())       /*(keystate()&FIRE)*/
            shoot();
      else 
        if (keystate()&QUIT)
          {
            lives=1;
            done=1;
          }


 /* Check for danger to the computers zapper in the form of a ball */ 
      if ((ball[cballn].ypos<31)&&
          ((ball[cballn].bdir==UP)||(ball[cballn].bdir==RESTING))&&
          (ball[cballn].bdir!=STOPPED))
        {
          indanger=1;
          bgdir=(bgpos<ball[cballn].xpos)?1:-1;
        }
      else
        {
          if ((currpos>(bgpos-2)) && (currpos<(bgpos+2)))
            if (srand(2))
              bgdir=-bgdir;   /* Add some srand motion if player is close */

          if (cnt==LOOPTIME)   /* Only move position after LOOPTIME loops */
            {
              cnt=0;   /* Reset our loop counter */
              if (homein)    /* If its hard, then home in on the player */
                bgdir=currpos<bgpos?-1:1;
              else   /* Move srandly */
                bgdir=srand(2)?-2:2;

              if ((bgpos>(currpos-szone)) &&  
                  (bgpos<(currpos+szone)))
                if (srand(2))
                  bgf();     /* Fire at the player now and then */
            }
        }  

      /* Zap a ball endangering the computers zapper if it is close enough */
      if ((indanger)&&(bgpos>ball[cballn].xpos-3)&&  
          (bgpos<ball[cballn].xpos+3))
        {
          bgf();
          indanger=0;
        }

      /* Update the computers zapper position, and loop counter */
      bgpos+=bgdir;
      cnt=cnt<LOOPTIME?cnt+1:0;
    }
  }

  color=ON;
  switch (whofired) 
  {
    case YOU : 
      {
        videodot(bgpos+5, 3+5); 
        videodot(bgpos-5, 3+5); 
        videodot(bgpos+2, 3+3); 
        videodot(bgpos-2, 3+3); 
        idelay(30000);
        videomode(3);
        break;
      }
    case BG : 
      {
        videodot(currpos+5, 58-5); 
        videodot(currpos-5, 58-5); 
        videodot(currpos+2, 58-3); 
        videodot(currpos-2, 58-3); 
        idelay(30000);
        videomode(3);
      }
  }
  printf("Final score - Me : %d   You : %d\n", bgscore, score);
  if (bgscore==score)
    printf("Nobody wins - play again.\n");
  else
    if (bgscore>score)
      printf("I win.  You were contaminated.\n");
    else
      printf("You win.  I was wasted with nukes.\n");
}

