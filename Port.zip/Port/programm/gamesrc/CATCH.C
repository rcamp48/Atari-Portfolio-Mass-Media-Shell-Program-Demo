/*      

  PROGRAM     : CATCH.C
  AUTHOR      : Jay Vaughan
  DATE        : 4 November 1991
  DESCRIPTION : Simple graphics game for the Atari Portfolio, using
                the GRLIB functions I developed for my Portfolio.
  NOTE        : See README.DOC for more information.
        
                      Copyright (C) 1991, 1992 Jay Vaughan

*/

#include <stdio.h> 
#include <conio.h>
#include <stdlib.h>
#include <time.h>

#include "grlib.h"
#include "keyb.h"
#include "gchar.h"

#define FIELDWIDTH 50

#define SCOREX 60 
#define SCOREY 28

#define LIVESX 60 
#define LIVESY 40

#define SCORELENGTH 3
#define LIVESLENGTH 3

#define MAXBALLS 10
#define MAXLOOPS 20

#define ON 1
#define OFF 0

#define DOWN 1

#define BOTTOM 58
#define TOP    2

int score, oscore=0;     /* Current score, last score */
int lives=20, olives=0;   /* Number of lives */
int cb=0;                /* Current ball */
int numb=0;              /* Number of balls currently on the screen */
int loops=0;             /* Number of loops */
int savecol;
int catch_y=60;          /* Catchers Y position */
int catch_x=50;          /* Catchers X position */
int oldcatch_x=20;       /* Catchers old X position */


struct balldef {
  int xpos, ypos;  /* The balls location on the field */
  int oypos;       /* The balls old y_pos */
  int velocity;    /* Velocity of the ball */
  int currv;       /* Speed counter */
  int on;          /* Boolean, 0=off 1=on */
};

struct balldef ball[MAXBALLS];

idelay(long time)
{
  int n;
  for (n=0;n<=time;n++);
}

initb(i)
int i;
{
  ball[i].on=0;
  ball[i].xpos=0;
  ball[i].ypos=5;
  ball[i].velocity=ball[i].currv=1+random(3);
  
}

initbs()
{
  int i;
  for (i=0;i<MAXBALLS;i++)
    initb(i);
}


setball(bn)
int bn;
{
  if (ball[bn].on==0)
    {
      ball[bn].on=1;
      ball[bn].xpos=2+(random((FIELDWIDTH-3)/2)*2);
      ball[bn].ypos=TOP;
      ball[bn].oypos=TOP;
    }
}


initgr()   /* Initialize graphics screen */
{
  /* Go into graphics */
  videomode(CGAMODE);
  color=ON;

  /* Draw the playing field */
  line(0,   0,  FIELDWIDTH, 0);          /*      ���      */
  line(FIELDWIDTH, 0,  FIELDWIDTH, 63);  /*         �     */
  line(0,   0,  0,   63);                /*     �         */
  line(0,   63, FIELDWIDTH+1, 63);       /*      ���      */

  /* Draw the score box */
  line(SCOREX-3,SCOREY-3, SCOREX+(SCORELENGTH*8)+3,SCOREY-3);
  line(SCOREX+(SCORELENGTH*8)+3,SCOREY-3, SCOREX+(SCORELENGTH*8)+3, SCOREY+7);
  line(SCOREX+(SCORELENGTH*8)+3, SCOREY+7, SCOREX-3, SCOREY+7);
  line(SCOREX-3, SCOREY+7,SCOREX-3,SCOREY-3);

  line(LIVESX-3,LIVESY-3, LIVESX+(LIVESLENGTH*8)+3,LIVESY-3);
  line(LIVESX+(LIVESLENGTH*8)+3,LIVESY-3, LIVESX+(LIVESLENGTH*8)+3, LIVESY+7);
  line(LIVESX+(LIVESLENGTH*8)+3, LIVESY+7, LIVESX-3, LIVESY+7);
  line(LIVESX-3, LIVESY+7,LIVESX-3,LIVESY-3);
}

init()  /* Initialize graphics, program variables etc. */
{  
  randomize();
  initbs();
  initgr();
  score=0;
  lives=10;
  printscore(score);
  printlives(lives);
}

deinit()
{
  videomode(TEXTMODE);
}

plotcatcher(int state, int *xpos)
{

  if (*xpos<=5)
    *xpos=5;
  else
   if (*xpos>=FIELDWIDTH-5)
     *xpos=FIELDWIDTH-5;

  savecol=color;
  color=state;
  dot(*xpos, catch_y);
  dot(*xpos-1, catch_y);
  dot(*xpos+1, catch_y);
  dot(*xpos-2, catch_y);
  dot(*xpos+2, catch_y);
  dot(*xpos-3, catch_y);
  dot(*xpos+3, catch_y);

  dot(*xpos-3, catch_y-1);
  dot(*xpos+3, catch_y-1);

  color=savecol;
}

plotballoff(bn)
int bn;
{
  color=OFF;
  dot(ball[bn].xpos-1, ball[bn].oypos);
  dot(ball[bn].xpos+1, ball[bn].oypos);
  dot(ball[bn].xpos, ball[bn].oypos-1);
  dot(ball[bn].xpos, ball[bn].oypos+1);
  dot(ball[bn].xpos-1, ball[bn].ypos);
  dot(ball[bn].xpos+1, ball[bn].ypos);
  dot(ball[bn].xpos, ball[bn].ypos-1);
  dot(ball[bn].xpos, ball[bn].ypos+1);
  color=ON;
}

plotball(bn)
int bn;
{  
  if (ball[bn].on)
    {
      if (ball[bn].currv<=0 )
        {
          color=OFF;
          dot(ball[bn].xpos-1, ball[bn].oypos);
          dot(ball[bn].xpos+1, ball[bn].oypos);
          dot(ball[bn].xpos, ball[bn].oypos-1);
          dot(ball[bn].xpos, ball[bn].oypos+1);
          color=ON;
          dot(ball[bn].xpos-1, ball[bn].ypos);
          dot(ball[bn].xpos+1, ball[bn].ypos);
          dot(ball[bn].xpos, ball[bn].ypos-1);
          dot(ball[bn].xpos, ball[bn].ypos+1);
          ball[bn].oypos=ball[bn].ypos;
          ball[bn].ypos+=(DOWN*ball[bn].velocity);
          ball[bn].currv=ball[bn].velocity;
        } 
      else
        ball[bn].currv--;
    }
}

plotballs()
{
  for(cb=0;cb<MAXBALLS;cb++)
    {
      plotball(cb);

      if ((ball[cb].ypos>BOTTOM)&&
         ((catch_x>=ball[cb].xpos-3)&&
          (catch_x<=ball[cb].xpos+3)))
        {
          plotballoff(cb);
          initb(cb);
          score+=1;
          if ((score%20)==0)
            lives++;
        }
      else
      if (ball[cb].ypos>BOTTOM)
        {
          plotballoff(cb);
          initb(cb);
          lives--;
        }
    }
}

play()
{
  while(lives>0) 
    {
      if (oscore!=score)
        {
          printscore(score);
          oscore=score;
        }
      if (olives!=lives)
        {
          printlives(lives);
          olives=lives;
        }

      plotcatcher(ON, &catch_x);
      if (oldcatch_x!=catch_x)
        {
          color=ON;
          plotcatcher(OFF, &oldcatch_x);
          oldcatch_x=catch_x;
        } 
      plotballs();

      if (keystate()&RSHIFT)  /* Check the players keystrokes */
        catch_x+=2;
      if (keystate()&LSHIFT)
        catch_x-=2;

      if ((random(11)>5)&&(loops==MAXLOOPS))
        setball(++numb);
      if (((score%100)>50)&&(numb>=MAXBALLS))
        numb=0;
      else 
      if (numb>=(MAXBALLS/2-1))
        numb=0;

      if (loops>MAXLOOPS)
        loops=0;
      else
        loops++;
    }
  printscore(score);

}

printlives(plives)
int plives;
{
  char livesstr[LIVESLENGTH];

  savecol=color;
  color=OFF;
  gfill(LIVESX-2, LIVESY-2, LIVESX+(LIVESLENGTH*8)+2, LIVESY+6);
  color=ON;

  sprintf(livesstr, "%d", plives);  
  bigprint(livesstr,LIVESX,LIVESY,1,1);   /* Print the new lives */
  color=savecol;
}

                         
printscore(pscore)
int pscore;
{
  char scorestr[SCORELENGTH];

  savecol=color;
  color=OFF;
  gfill(SCOREX-2, SCOREY-2, SCOREX+(SCORELENGTH*8)+2, SCOREY+6);
  color=ON;

  sprintf(scorestr, "%d", pscore);
  bigprint(scorestr,SCOREX,SCOREY,1,1);          /* Print the new score */
  color=savecol;
}

printintro()
{
  color=ON;
  bigprint("GAME START",100,34,1,1);
  getch();
  color=OFF;
  bigprint("GAME START",100,34,1,1);

  color=ON;
  bigprint("CATCH THE FALLING ", 90, 20, 1, 1);
  bigprint("BALLS.  USE THE   ", 90, 30, 1, 1);
  bigprint("SHIFT KEYS TO MOVE", 90, 40, 1, 1);
}

die()
{ 
  gfilv(0,0,FIELDWIDTH,63);
  gfilh(0,0,FIELDWIDTH,63);
}

printexit()
{
  color=OFF;
  bigprint("CATCH THE FALLING ", 90, 20, 1, 1);
  bigprint("BALLS.  USE THE   ", 90, 30, 1, 1);
  bigprint("SHIFT KEYS TO MOVE", 90, 40, 1, 1);
  color=ON;
  bigprint("GAME OVER",100,34,1,1);
  printscore(score);
  printlives(lives);
  getch();
}


main()
{
  init();

  color=ON;
  line(0,0,239,0);
  line(239,0,239,63);
  line(239,63,0,63);
  line(0,63,0,0);

  printintro();

  play();
  die();
  printexit();
  deinit();
}

