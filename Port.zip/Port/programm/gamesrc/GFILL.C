extern line();

void gfill(x1, y1, x2, y2)
int x1, y1, x2, y2;
{
    int tmp;

    if(x1 > x2)
        tmp = x2, x2 = x1, x1 = tmp;
    while(x1 <= x2) {
        line(x1, y1, x1, y2);
        x1++;
    }
}

