#include <conio.h>

void main()
{
  char c;
  while (c!='j')
    {
      c=getch();
      printf("%c,\t%d\n", c, c);
    }
}

