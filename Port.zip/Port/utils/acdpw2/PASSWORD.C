 /***************************************************************
 * password.c -- simple password protection for the portfolio   *
 *                                                              *
 * Author : Alan Davis CIS:72317,3661                           *
 *                                                              *
 * Implementation : TurboC v2.0                                 *
 *                                                              *
 * edits                                                        *
 * 1.1  added c_break protection                                *
 *                                                              * 
 *    This program is hereby dedicated to the PUBLIC DOMAIN     *
 ***************************************************************/


#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <setjmp.h>
#include <dos.h>

#define PWLEN 10
#define BS    8
#define CR    13
#define SP    32

jmp_buf restart;
int c_break(void);

int i, c;			/* counter       */
char *pwd,			/* user password */
*text[5],			/* usage message */
*ind,				/* buffer        */
 prompt[] = "Enter Password : ";


main(argc, argv)
    int argc;
    char **argv;
{

    ctrlbrk(c_break); /* set new control-break handler */

    text[0] = "passwd V1.1\n";
    text[1] = "Alan Davis, Sept 1990\n\n";
    text[2] = "Usage : passwd phlugg\n";
    text[3] = "Where phlugg is the password\n";
    text[4] = "Password is limited to 10 chars.\n";
    i = 0;

    /* check for no password on command line */
    if (argc <= 1)
    {
usage:				/* print usage message */
	for (c = 0; c <= 4; c++)
	{
	    ind = text[c];
	    for (i = 0; ind[i] != NULL; i++)
		putchar(ind[i]);
	}
	exit(1);
    }
    else			/* make sure password isn't too long */
    {
	for (i = 0; argv[1][i] != NULL; i++);
	if (i > PWLEN)
	    goto usage;		/* yuck!, but it saves code */
    }

    pwd = (char *) malloc(11 * sizeof(char));

    setjmp(restart); /* this is where we come to on ctrl-c */

    /* prompt for the password */
    while (1)
    {

	for (i = 0; prompt[i] != NULL; i++)
	    putchar(prompt[i]);
	i = c = 0;

	/* and get it, don't let it get too long */
	while ((c = getch()) != CR && i < PWLEN)
	{
	    putchar('*');
	    pwd[i++] = c;

	}
	pwd[i] = NULL;

	/* check it */
	if (!stricmp(pwd, argv[1]))
	{
	    putchar(CR);
	    exit(1);		/* if it's ok */
	}
	for (c = i; c != 0; c--)/* else clear the line and reprompt */
	    putchar(BS);
	for (c = i; c != 0; c--)
	    putchar(SP);

	putchar(CR);
    }
}

int c_break(void)
{
    longjmp(restart,1);
}

