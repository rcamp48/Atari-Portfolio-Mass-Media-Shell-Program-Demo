/*
** Greig Greenwald -- December 17, 1990 -- Turbo C 1.0
**
** Incremental backup for the Atari Portfolio.
** As written, this program handles one Portfolio directory and backs it
** up to one PC directory.  I keep all of my data on the A: of the Portfolio
** with no subdirectories.  The backup directory is C:\FOLIO\A\ on the PC.
** This program assumes the existence of C:\DIRECT.ORY on the Portfolio,
** which is a redirected directory listing of A.  I use a batch file with the
** following commands:
**
**     DIR A:\*.* > C:\DIRECT.ORY
**     APP /S
**     DEL C:\DIRECT.ORY
**
** All of the paths and filenames are read from the profile for ease of
** changing.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <io.h>
#include <fcntl.h>
#include <process.h>

#define    StringLength            80
#define    CommentMarker           '#'
#define    Space                   ' '

void Read_Profile_Word
     ( char  word[],
       FILE *fp );

void main ( int argc, char *argv[] )
{

  int           i;
  FILE         *PFDir;
  int           fhan;
  char          ft[6];
  char          buf[StringLength + 10];
  char          buf2[StringLength + 10];
  long          insize;
  int           inmonth;
  int           inday;
  int           inyear;
  int           inhour;
  int           inminute;
  char          FileName[15];
  struct ftime  Time;
  long          size;
  int           DosError;
  int           scan;
  char          ProfileName[StringLength];
  FILE         *ProfileFile;
  char          File_Transfer_Program[StringLength];
  char          Portfolio_Directory[StringLength];
  char          Dir_File_On_Portfolio[StringLength];
  char          PC_Backup_Dir[StringLength];
  char          Dir_File_On_PC[StringLength];
  char          ampm;

  /*
  ** Get the name of the profile.
  */
  strcpy( ProfileName, argv[0] );
  i = strlen( ProfileName );
  ProfileName[i-3] = 'P';
  ProfileName[i-2] = 'R';
  ProfileName[i-1] = 'O';

  if ((ProfileFile = fopen( ProfileName, "r")) == NULL) {
    printf( "Profile, %s, not found.\n", ProfileName );
    exit( 0 );
  } /* end if */

  /*
  ** Read the name of the file transfer program from the profile.
  */
  Read_Profile_Word( File_Transfer_Program, ProfileFile );

  /*
  ** While the profile is not empty...
  */
  while (!feof(ProfileFile)) {

    /*
    ** Read one line of information from the profile.
    */
    Read_Profile_Word( Portfolio_Directory,   ProfileFile );
    Read_Profile_Word( Dir_File_On_Portfolio, ProfileFile );
    Read_Profile_Word( PC_Backup_Dir,         ProfileFile );
    Read_Profile_Word( Dir_File_On_PC,        ProfileFile );


    if (!feof(ProfileFile)) {

      /*
      ** Get the Portfolio's directory...
      */
      printf( "Receiving the Portfolio %s directory file (%s)...\n",
              Portfolio_Directory, Dir_File_On_Portfolio );
      if ((fhan = open( Dir_File_On_PC, O_RDONLY )) >= 0 )
      {
        close( fhan );
        remove( Dir_File_On_PC );
      }

      DosError = spawnl( P_WAIT,
                         File_Transfer_Program,
                         File_Transfer_Program,
                         Dir_File_On_Portfolio,
                         Dir_File_On_PC,
                         "/R",
                         NULL );

      if (DosError != 0) {
        printf( "DOS Error # %d\n", DosError );
        exit(0);
      } /* end if */

      if ((PFDir = fopen( Dir_File_On_PC, "r")) == NULL) {
        printf( "Cannot find %s on the PC.\n", Dir_File_On_PC );
        printf( "It is possible that %s does not exist\n", Dir_File_On_Portfolio );
        printf( "on the Portfolio and therefore was not transferred to the PC.\n" );
      } /* end if */

      /*
      ** Read the directory header and discard it.
      */
      for (i = 1; i <= 4; i++) {
        fgets( &buf, StringLength, PFDir );
      } /* end for */

      /*
      ** For each file in the directory file, compare it to what is in the
      ** backup directory.
      */
      do {

        scan = fscanf( PFDir, "%s %s %ld %d-%d-%d %d:%d%c",
                              FileName, ft, &insize, &inmonth, &inday, &inyear,
                              &inhour, &inminute, &ampm );

        /*
        ** Testing code:
        **
        ** printf( "Scan  : %d\n", scan );
        ** printf( "FileN : %s\n", FileName );
        ** printf( "FileE : %s\n", ft );
        ** printf( "Size  : %ld\n", insize );
        ** printf( "Month : %d\n", inmonth );
        ** printf( "Day   : %d\n", inday );
        ** printf( "Year  : %d\n", inyear );
        ** printf( "Hour  : %d\n", inhour );
        ** printf( "Min   : %d\n", inminute );
        ** buf[0] = (char) getchar();
        */

        if (scan == 9) {
          strcpy( buf, "." );
          strcat( FileName, strcat( buf, ft ) );
          strcpy( buf, PC_Backup_Dir );
          if ((fhan = open( strcat( buf, FileName ), O_RDONLY)) < 0) {

            /*
            ** The file is not in the backup directory.
            */
            printf( "Receiving %s...\n", FileName );
            strcpy( buf,  Portfolio_Directory );
            strcpy( buf2, PC_Backup_Dir );
            DosError = spawnl( P_WAIT,
                               File_Transfer_Program,
                               File_Transfer_Program,
                               strcat( buf, FileName ),
                               strcat( buf2, "*.*"),
                               "/R",
                               NULL );
            if (DosError != 0) {
              printf( "DOS Error # %d\n", DosError );
              exit(0);
            } /* end if */

          } else {

            /*
            ** Convert the file information found in the directory file in to
            ** the same format of the data retrieved for the file in the
            ** backup directory so that they can be compared.
            */

            if (ampm == 'p' && inhour < 12) {
              inhour += 12;             /* military time */
            }
            else if (ampm == 'a' && inhour == 12) {
              inhour = 0;
            } /* end if */

            inyear -= 80;               /* 1980 */

            /*
            ** Get the data on the file that is in the backup directory.
            */
            getftime( fhan, &Time );
            size = filelength( fhan );

            close( fhan );

            /*
            ** Testing code:
            **
            ** printf( "Month : %d^%d\n", Time.ft_month, inmonth );
            ** printf( "Day   : %d^%d\n", Time.ft_day, inday );
            ** printf( "Year  : %d^%d\n", Time.ft_year, inyear );
            ** printf( "Hour  : %d^%d\n", Time.ft_hour, inhour );
            ** printf( "Min   : %d^%d\n", Time.ft_min, inminute );
            ** printf( "Size  : %ld^%ld\n", size, insize );
            ** buf[0] = (char) getchar();
            */

            if (( Time.ft_month != inmonth  ) ||
                ( Time.ft_day   != inday    ) ||
                ( Time.ft_year  != inyear   ) ||
                ( Time.ft_hour  != inhour   ) ||
                ( Time.ft_min   != inminute ) ||
                ( size          != insize   ))
            {

              printf( "Replacing %s...\n", FileName );
              strcpy( buf, PC_Backup_Dir );
              remove( strcat( buf, FileName ) );
              strcpy( buf,  Portfolio_Directory );
              strcpy( buf2, PC_Backup_Dir );
              DosError = spawnl( P_WAIT,
                                 File_Transfer_Program,
                                 File_Transfer_Program,
                                 strcat( buf, FileName ),
                                 strcat( buf2, "*.*" ),
                                 "/R",
                                 NULL );
              if (DosError != 0) {
                printf( "DOS Error # %d\n", DosError );
                exit( 0 );
              } /* end if */

            } /* end if */

          } /* end if */

        } else {
          if (strcmp( ft, "<DIR>" ) == 0) {
            fgets( buf, StringLength, PFDir );
          } /* end if */
        } /* end if */
      } while ( !feof(PFDir) && (scan == 9 || strcmp( ft, "<DIR>" ) == 0) );

      fclose( PFDir );
    } /* end if */
  } /* end while */
} /* main */


void Read_Profile_Word
     ( char  word[],
       FILE *fp )
{
  fscanf( fp, "%s", word );
  while (word[0] == CommentMarker) {
    fgets( word, StringLength, fp);
    fscanf( fp, "%s", word );
  } /* end while */
} /* Read_Profile_Word */
